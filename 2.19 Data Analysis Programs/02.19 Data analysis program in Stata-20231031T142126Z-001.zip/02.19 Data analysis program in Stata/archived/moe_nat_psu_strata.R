moe=function(prob,rs,wt=NULL,psu,sampl.strata){
  # Computes margins of error around the estimated prevalence, as the result of the
  # combination of sampling error and measurement error
  # prob = probability of being beyond the threshold for each case
  # rs = raw score for each case
  # wt = weight to be assigned to each case
  # Compute the average probability for each rs
  n = length(prob)
  if (is.null(wt)) {wt = rep(1,n)}
  if (is.null(sd)) {sd = 1}
  options(survey.lonely.psu="average")
  svydesign=svydesign(id=~psu, strata = ~sampl.strata, weights = ~ wt,
                      data=data.frame(prob)) # Apply complex design formula (CDF) To be updated if sampling strata/psu info are provided
  se_s = SE(svymean(~prob, svydesign,  deff = T,na.rm=T))
  p = sort(unique(prob))%*%table(prob,rs)/colSums(table(prob,rs))
  wrs = NULL
  for (i in sort(unique(rs))){
    wrs[i+1] = sum(wt[which(rs==i)])/sum(wt)*length(wt)
  }
  var_m = (p*(1-p)/n)%*%(wrs/sum(wrs))^2
  se_m = sqrt(var_m)
  se = sqrt(se_s^2+se_m^2)
# moe = se*1.645 # 90% confidence interval
  moe = se*1.96  # 95% confidence interval
  return(c(moe))
# return(c(se))
}